var jake, jake_running

function preload() {
  //pre-load images
  jake_running1 = loadAnimation("Jake1.png","Jake2.png","jake3.png","jake4.PNG","jake5.png")
  pathImg = loadImage("path.png")
}

function setup() {
  createCanvas(400, 400);
  //create sprites here
  path = createSprite(200, 200);
  path.addImage(pathImg);
  path.velocityY = 4;
  Jake = createSprite(100, 300, 20, 20);
  Jake.addAnimation("running", jake_running1);
  boundary1 = createSprite(60, 200, 10, 400);
  boundary1.visible = false;

  boundary2 = createSprite(340, 200, 10, 400);
  boundary2.visible = false;

}

function draw() {
  background("black");
  Jake.x = mouseX;

  if (path.y > 400) {
    path.y = height / 2
  }

  if (keyDown("L")) {
    Jake.velocityX = -2;
  }
  Jake.collide(boundary1);
  Jake.collide(boundary2);

  if (keyDown("R")) {
    Jake.velocityX = 2;
  }
  drawSprites();

}